from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image, UnidentifiedImageError
from io import BytesIO
import os

app = FastAPI(title="AgroVision AI Backend", version="0.1.0")

# For production, replace "*" with the exact domain hosting your app.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

MAX_IMAGE_BYTES = 8 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}

@app.get("/")
def root():
    return {"app": "AgroVision AI Backend", "status": "running"}

@app.get("/health")
def health():
    return {"status": "ok", "model_configured": False}

@app.post("/predict")
async def predict(image: UploadFile = File(...)):
    if image.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=415, detail="Upload a JPG, PNG, or WEBP image.")

    content = await image.read()
    if not content:
        raise HTTPException(status_code=400, detail="The uploaded image is empty.")
    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="Image must be 8 MB or smaller.")

    try:
        with Image.open(BytesIO(content)) as img:
            img.verify()
    except (UnidentifiedImageError, OSError):
        raise HTTPException(status_code=400, detail="The uploaded file is not a valid image.")

    # Real prediction is intentionally not fabricated.
    # Add a validated crop-disease model and its preprocessing/postprocessing here.
    model_path = os.getenv("MODEL_PATH", "")
    if not model_path or not os.path.isfile(model_path):
        raise HTTPException(
            status_code=503,
            detail=(
                "AI model is not installed yet. Add a validated crop-disease model "
                "and implement its preprocessing and prediction in app/model.py."
            ),
        )

    # Model-specific inference cannot be safely guessed: input size, labels,
    # normalization and output mapping depend on the exact trained model.
    raise HTTPException(
        status_code=501,
        detail="Model file found, but model-specific inference is not configured yet."
    )
