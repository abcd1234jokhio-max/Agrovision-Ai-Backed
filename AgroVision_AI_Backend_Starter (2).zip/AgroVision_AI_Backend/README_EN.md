# AgroVision AI Backend Starter

This is a backend scaffold. It accepts an image and validates its file type and image integrity. **It does not diagnose crop disease yet.** A trained and validated crop-disease model must be integrated before real predictions are possible.

## Endpoints
- `GET /` — service status
- `GET /health` — health check
- `POST /predict` — multipart form-data image field named `image`

Without a model, `/predict` returns HTTP 503 rather than inventing a diagnosis.

## Run locally
Requires Python 3.11.
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000/docs`.

## Connect the HTML app
1. Deploy this backend to a hosting provider with HTTPS.
2. Copy the deployed base URL.
3. In AgroVision AI, open **AI connection settings**.
4. Set the backend URL to `https://YOUR-HOST/predict`.
5. Check `https://YOUR-HOST/health`.

## Still required for real AI
A validated model, its preprocessing rules, class labels, output mapping, and Pakistan-relevant field validation. The correct implementation depends on the exact model file; this starter deliberately does not guess those details.
