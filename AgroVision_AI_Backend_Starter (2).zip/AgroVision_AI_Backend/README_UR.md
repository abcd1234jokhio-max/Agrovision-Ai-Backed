# AgroVision AI Backend (Starter)

هي backend جو شروعاتي ڍانچو آهي. اهو تصوير وصول ڪري، فائيل جي قسم ۽ صحيح هجڻ جي جاچ ڪري ٿو. **هي پاڻمرادو فصل جي بيماري نٿو سڃاڻي**؛ حقيقي سڃاڻپ لاءِ تصديق ٿيل ۽ تربيت يافته crop-disease model لازمي آهي.

## API
- `GET /` — backend هلڻ جي حالت
- `GET /health` — health check
- `POST /predict` — multipart form-data ۾ `image` نالي تصوير

ماڊل موجود نه هئڻ تي `/predict` واضح `503` جواب ڏيندو؛ ڪو به فرضي نتيجو نه ڏيندو.

## مقامي طور هلائڻ
Python 3.11 انسٽال ڪريو، پوءِ هن فولڊر اندر:
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
برائوزر ۾ `http://127.0.0.1:8000/docs` کوليو.

## ApkForge / HTML سان ڳنڍڻ
1. Backend کي HTTPS سان ڪنهن hosting سروس تي deploy ڪريو.
2. Deploy ٿيل پتو وٺو، مثال: `https://your-backend.example`
3. AgroVision AI ايپ ۾ **AI connection settings** کوليو.
4. Backend URL طور `https://your-backend.example/predict` ڏيو.
5. پهرين `https://your-backend.example/health` کوليو ۽ status چيڪ ڪريو.

## حقيقي AI شامل ڪرڻ لاءِ اڃا گهربل شيون
- سڀني گهربل فصلن ۽ بيمارين تي صحيح نموني تربيت ۽ جاچ ڪيل model (مثلاً TensorFlow Lite يا TensorFlow/Keras).
- ماڊل جي input size، image normalization، class labels ۽ output format.
- پاڪستان جي مقامي فصلن ۽ بيمارين تي validation.
- ماڊل جي اڳڪٿيءَ سان گڏ confidence ۽ ماهر طرفان تصديق ٿيل محفوظ صلاحون.

**احتياط:** صرف AI نتيجي جي بنياد تي جراثيم ڪش يا ٻيون زرعي دوائون استعمال نه ڪرايو. مقامي زرعي ماهر سان تصديق ۽ پراڊڪٽ جي ليبل تي عمل ضروري آهي.
