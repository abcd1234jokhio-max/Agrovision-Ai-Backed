AgroVision AI backend starter.
Upload main.py, requirements.txt and Dockerfile to the ROOT of your GitHub repository.
Render settings: Runtime Docker; Root Directory blank; deploy.
After deploy test /health. /predict currently validates images but returns 503 because a trained crop disease model is not yet connected.
