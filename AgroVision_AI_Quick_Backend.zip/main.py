from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image, UnidentifiedImageError
from io import BytesIO

app = FastAPI(title="AgroVision AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your app's domain before production.
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {"app": "AgroVision AI", "status": "running"}

@app.get("/health")
def health():
    return {"status": "ok", "ai_model_connected": False}

@app.post("/predict")
async def predict(image: UploadFile = File(...)):
    if image.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(415, "Upload a JPG, PNG, or WEBP image.")
    data = await image.read()
    if not data:
        raise HTTPException(400, "Image is empty.")
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(413, "Image must be 8 MB or smaller.")
    try:
        with Image.open(BytesIO(data)) as im:
            im.verify()
    except (UnidentifiedImageError, OSError):
        raise HTTPException(400, "Invalid image file.")

    # No crop-disease model is installed yet. Do not invent a diagnosis.
    raise HTTPException(
        503,
        "Backend is working, but the trained crop-disease AI model has not been connected yet."
    )
